'use client';

import ProductForm from './product-form';

type TProductViewPageProps = {
  product: {
    artikelnummer: number;
    name: string;
    supplier: string;
    price: number;
    minStock: number;
    description: string;
    image: File[];
  };
  pageTitle: string;
};

export default function ProductViewPage({
  product,
  pageTitle
}: TProductViewPageProps) {
  return <ProductForm initialData={product} pageTitle={pageTitle} />;
}
