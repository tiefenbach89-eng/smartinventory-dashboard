'use client';

import * as React from 'react';
import { createClient } from '@/lib/supabase/client';
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Loader2, TrendingUp, Turtle } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

export function RecentSales() {
  const supabase = createClient();

  type Mover = {
    artikelnummer: string;
    artikelname: string;
    menge: number;
    lieferant?: string | null;
    preis?: number | null;
  };

  const [loading, setLoading] = React.useState(true);
  const [topMovers, setTopMovers] = React.useState<Mover[]>([]);
  const [slowMovers, setSlowMovers] = React.useState<Mover[]>([]);

  const [selectedProduct, setSelectedProduct] = React.useState<{
    nummer: string;
    name: string;
    lieferant?: string | null;
    preis?: number | null;
  } | null>(null);

  const [articleLogs, setArticleLogs] = React.useState<
    {
      timestamp: string;
      aktion: string;
      menge_diff: number;
      kommentar: string | null;
      benutzer?: string | null;
      lieferscheinnr?: string | null;
    }[]
  >([]);

  const [logLoading, setLogLoading] = React.useState(false);

  // 🔹 Bewegungsdaten laden (Top & Slow Movers)
  React.useEffect(() => {
    const fetchMovers = async () => {
      try {
        setLoading(true);
        const since = new Date(
          Date.now() - 30 * 24 * 60 * 60 * 1000
        ).toISOString();

        const { data: logs, error } = await supabase
          .from('artikel_log')
          .select(
            'artikelnummer, artikelname, menge_diff, lieferant, preis_snapshot'
          )
          .gte('timestamp', since);

        if (error) throw error;
        if (!logs) return;

        const totalMoves: Record<string, number> = {};
        logs.forEach((l) => {
          const qty = Math.abs(l.menge_diff ?? 0);
          if (!isNaN(qty)) {
            totalMoves[l.artikelnummer] =
              (totalMoves[l.artikelnummer] ?? 0) + qty;
          }
        });

        const moverArray = Object.entries(totalMoves)
          .map(([artikelnummer, menge]) => {
            const log = logs.find(
              (l) => String(l.artikelnummer) === String(artikelnummer)
            );
            return {
              artikelnummer,
              artikelname: log?.artikelname || `Artikel #${artikelnummer}`,
              lieferant: log?.lieferant || '—',
              preis: log?.preis_snapshot || null,
              menge
            };
          })
          .sort((a, b) => b.menge - a.menge);

        const top = moverArray.slice(0, 3);
        const slow = moverArray.slice(-3).reverse();

        setTopMovers(top);
        setSlowMovers(slow);
      } catch (err) {
        console.error('❌ Movement Fetch Error:', err);
        toast.error('Failed to load movement data.');
      } finally {
        setLoading(false);
      }
    };

    fetchMovers();
  }, [supabase]);

  // 🔹 Logs für Artikel abrufen
  async function fetchLogsForArticle(article: {
    nummer: string;
    name: string;
    lieferant?: string | null;
    preis?: number | null;
  }) {
    try {
      setLogLoading(true);
      setSelectedProduct(article);

      const since = new Date(
        Date.now() - 30 * 24 * 60 * 60 * 1000
      ).toISOString();

      const { data, error } = await supabase
        .from('artikel_log')
        .select(
          'timestamp, aktion, menge_diff, kommentar, benutzer, lieferscheinnr'
        )
        .eq('artikelnummer', article.nummer)
        .gte('timestamp', since)
        .order('timestamp', { ascending: false });

      if (error) throw error;
      setArticleLogs(data ?? []);
    } catch (err) {
      console.error('❌ Log fetch error:', err);
      toast.error('Failed to load article log.');
    } finally {
      setLogLoading(false);
    }
  }

  return (
    <>
      <Card className="@container/card w-full !h-[400px] !min-h-[400px] flex flex-col overflow-hidden">
        <CardHeader>
          <CardTitle>Top & Slow Movers (30 Days)</CardTitle>
          <CardDescription>
            Quantity-based movement analysis for the last month
          </CardDescription>
        </CardHeader>

        <CardContent className="w-full min-w-0 flex-1 flex flex-col justify-between overflow-auto">
          {loading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="text-muted-foreground h-6 w-6 animate-spin" />
            </div>
          ) : (
            <div className="flex-1 w-full min-w-0 flex flex-col justify-between">
              {/* --- Top Movers --- */}
              <div>
                <h3 className="mb-2 flex items-center gap-1 text-sm font-semibold text-green-500">
                  <TrendingUp className="h-4 w-4" /> Top Movers
                </h3>
                <div className="w-full overflow-x-auto">
                  <Table className="mb-6 w-full min-w-[400px]">
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[60px]">Rank</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead className="text-right">Quantity</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {topMovers.length === 0 ? (
                        <TableRow>
                          <TableCell
                            colSpan={3}
                            className="text-center text-muted-foreground py-4"
                          >
                            No data available
                          </TableCell>
                        </TableRow>
                      ) : (
                        topMovers.map((item, index) => (
                          <TableRow
                            key={`top-${item.artikelnummer}`}
                            className="hover:bg-muted/50 cursor-pointer transition"
                            onClick={() =>
                              fetchLogsForArticle({
                                nummer: item.artikelnummer,
                                name: item.artikelname,
                                lieferant: item.lieferant,
                                preis: item.preis
                              })
                            }
                          >
                            <TableCell className="font-medium">
                              {index === 0 && '🥇'}
                              {index === 1 && '🥈'}
                              {index === 2 && '🥉'}
                            </TableCell>
                            <TableCell>{item.artikelname}</TableCell>
                            <TableCell className="text-right font-semibold">
                              {item.menge}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* --- Slow Movers --- */}
              <div>
                <h3 className="mb-2 flex items-center gap-1 text-sm font-semibold text-amber-500">
                  <Turtle className="h-4 w-4" /> Slow or Inactive Movers
                </h3>
                <div className="w-full overflow-x-auto">
                  <Table className="w-full min-w-[400px]">
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[60px]">Rank</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead className="text-right">Quantity</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {slowMovers.length === 0 ? (
                        <TableRow>
                          <TableCell
                            colSpan={3}
                            className="text-center text-muted-foreground py-4"
                          >
                            No data available
                          </TableCell>
                        </TableRow>
                      ) : (
                        slowMovers.map((item, index) => (
                          <TableRow
                            key={`slow-${item.artikelnummer}`}
                            className="hover:bg-muted/50 cursor-pointer transition"
                            onClick={() =>
                              fetchLogsForArticle({
                                nummer: item.artikelnummer,
                                name: item.artikelname,
                                lieferant: item.lieferant,
                                preis: item.preis
                              })
                            }
                          >
                            <TableCell className="text-muted-foreground font-medium">
                              🐢 {index + 1}
                            </TableCell>
                            <TableCell>{item.artikelname}</TableCell>
                            <TableCell className="text-muted-foreground text-right font-semibold">
                              {item.menge}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 🧾 Product Movement Details Modal */}
      <Dialog
        open={!!selectedProduct}
        onOpenChange={() => setSelectedProduct(null)}
      >
        <DialogContent className="w-full max-w-4xl">
          <DialogHeader>
            <DialogTitle>
              {selectedProduct?.name || 'Product Movements'}
            </DialogTitle>
            <CardDescription>
              Detailed movement log for this product, including delivery notes.
            </CardDescription>
          </DialogHeader>

          {logLoading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="text-muted-foreground h-6 w-6 animate-spin" />
            </div>
          ) : articleLogs.length === 0 ? (
            <p className="text-muted-foreground text-sm">No movements found.</p>
          ) : (
            <div className="mt-3 overflow-hidden rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead className="text-right">Quantity</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Delivery Note</TableHead>
                    <TableHead>Comment</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {articleLogs.map((log, i) => (
                    <TableRow key={i}>
                      <TableCell>
                        {new Date(log.timestamp).toLocaleDateString('en-GB')}
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            log.menge_diff >= 0
                              ? 'bg-green-500/20 text-green-600'
                              : 'bg-red-500/20 text-red-500'
                          }
                        >
                          {log.menge_diff >= 0 ? 'Added' : 'Removed'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        {Math.abs(log.menge_diff)}
                      </TableCell>
                      <TableCell>{log.benutzer || 'System'}</TableCell>
                      <TableCell>
                        {log.lieferscheinnr ? (
                          <span className="text-primary font-medium">
                            {log.lieferscheinnr}
                          </span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell>{log.kommentar || '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
