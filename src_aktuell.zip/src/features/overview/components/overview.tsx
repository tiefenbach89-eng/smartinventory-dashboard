'use client';

import PageContainer from '@/components/layout/page-container';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
  CardAction
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AreaGraph from './area-graph';
import { BarGraph } from './bar-graph';
import { PieGraph } from './pie-graph';
import { RecentSales } from './recent-sales';
import { IconTrendingUp, IconTrendingDown } from '@tabler/icons-react';
import { Badge } from '@/components/ui/badge';

export default function OverViewPage() {
  return (
    <PageContainer>
      <div className="flex flex-1 flex-col space-y-2">
        {/* Header */}
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-2xl font-bold tracking-tight">
            Hi, Welcome back
          </h2>
          <div className="hidden items-center space-x-2 md:flex">
            <Button>Download</Button>
          </div>
        </div>

        {/* Tabs Section */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analytics" disabled>
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Overview Content */}
          <TabsContent value="overview" className="space-y-4">
            {/* ─── KPI Cards ───────────────────────────────────────────── */}
            <div className="*:data-[slot=card]:from-primary/5 *:data-[slot=card]:to-card dark:*:data-[slot=card]:bg-card grid grid-cols-1 gap-4 px-4 *:data-[slot=card]:bg-gradient-to-t *:data-[slot=card]:shadow-xs lg:px-6 @xl/main:grid-cols-2 @5xl/main:grid-cols-4">
              {/* Card 1 */}
              <Card className="@container/card">
                <CardHeader>
                  <CardDescription>Total Revenue</CardDescription>
                  <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
                    $1,250.00
                  </CardTitle>
                  <CardAction>
                    <Badge variant="outline">
                      <IconTrendingUp />
                      +12.5%
                    </Badge>
                  </CardAction>
                </CardHeader>
                <CardFooter className="flex-col items-start gap-1.5 text-sm">
                  <div className="line-clamp-1 flex gap-2 font-medium">
                    Trending up this month <IconTrendingUp className="size-4" />
                  </div>
                  <div className="text-muted-foreground">
                    Visitors for the last 6 months
                  </div>
                </CardFooter>
              </Card>

              {/* Card 2 */}
              <Card className="@container/card">
                <CardHeader>
                  <CardDescription>New Customers</CardDescription>
                  <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
                    1,234
                  </CardTitle>
                  <CardAction>
                    <Badge variant="outline">
                      <IconTrendingDown />
                      -20%
                    </Badge>
                  </CardAction>
                </CardHeader>
                <CardFooter className="flex-col items-start gap-1.5 text-sm">
                  <div className="line-clamp-1 flex gap-2 font-medium">
                    Down 20% this period <IconTrendingDown className="size-4" />
                  </div>
                  <div className="text-muted-foreground">
                    Acquisition needs attention
                  </div>
                </CardFooter>
              </Card>

              {/* Card 3 */}
              <Card className="@container/card">
                <CardHeader>
                  <CardDescription>Active Accounts</CardDescription>
                  <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
                    45,678
                  </CardTitle>
                  <CardAction>
                    <Badge variant="outline">
                      <IconTrendingUp />
                      +12.5%
                    </Badge>
                  </CardAction>
                </CardHeader>
                <CardFooter className="flex-col items-start gap-1.5 text-sm">
                  <div className="line-clamp-1 flex gap-2 font-medium">
                    Strong user retention <IconTrendingUp className="size-4" />
                  </div>
                  <div className="text-muted-foreground">
                    Engagement exceeds targets
                  </div>
                </CardFooter>
              </Card>

              {/* Card 4 */}
              <Card className="@container/card">
                <CardHeader>
                  <CardDescription>Growth Rate</CardDescription>
                  <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
                    4.5%
                  </CardTitle>
                  <CardAction>
                    <Badge variant="outline">
                      <IconTrendingUp />
                      +4.5%
                    </Badge>
                  </CardAction>
                </CardHeader>
                <CardFooter className="flex-col items-start gap-1.5 text-sm">
                  <div className="line-clamp-1 flex gap-2 font-medium">
                    Steady performance increase{' '}
                    <IconTrendingUp className="size-4" />
                  </div>
                  <div className="text-muted-foreground">
                    Meets growth projections
                  </div>
                </CardFooter>
              </Card>
            </div>

            {/* ─── Charts & Tables Grid ──────────────────────────────── */}
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-7">
              {/* Left column (2 Karten übereinander, gleiche Höhe) */}
              <div className="col-span-full lg:col-span-4 flex flex-col gap-4">
                {/* Stock Overview */}
                <div className="h-[400px]">
                  <div className="h-full">
                    <BarGraph />
                  </div>
                </div>

                {/* Inventory Value Over Time */}
                <div className="h-[400px]">
                  <div className="h-full">
                    <AreaGraph />
                  </div>
                </div>
              </div>

              {/* Right column (2 Karten übereinander, gleiche Höhe) */}
              <div className="col-span-full lg:col-span-3 flex flex-col gap-4">
                {/* Top & Slow Movers */}
                <div className="h-[400px]">
                  <div className="h-full">
                    <RecentSales />
                  </div>
                </div>

                {/* Supplier Distribution */}
                <div className="h-[400px]">
                  <Card className="@container/card w-full h-full overflow-hidden">
                    <PieGraph />
                  </Card>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PageContainer>
  );
}
