import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import OverViewPage from '@/features/overview/components/overview';

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // 🔐 Wenn kein Benutzer eingeloggt ist → Weiterleitung zur Login-Seite
  if (!user) {
    redirect('/auth/sign-in');
  }

  // ✅ Wenn eingeloggt → rendere die echte Overview-Seite
  return <OverViewPage />;
}
