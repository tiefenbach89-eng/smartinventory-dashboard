export { default } from '../sign-in/page';
