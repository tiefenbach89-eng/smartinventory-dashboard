'use client';
import { useLocale } from 'next-intl';

export default function LanguageSwitch() {
  const locale = useLocale();

  const switchLanguage = (lang: 'en' | 'de') => {
    if (lang === locale) return;
    document.cookie = `NEXT_LOCALE=${lang}; Path=/; Max-Age=31536000; SameSite=Lax`;
    window.location.assign(window.location.pathname + window.location.search);
  };

  return (
    <div className="flex justify-center gap-2 mt-2">
      <button
        onClick={() => switchLanguage('en')}
        className={`px-2 py-1 border rounded ${
          locale === 'en' ? 'bg-muted' : 'opacity-70'
        }`}
      >
        EN
      </button>
      <button
        onClick={() => switchLanguage('de')}
        className={`px-2 py-1 border rounded ${
          locale === 'de' ? 'bg-muted' : 'opacity-70'
        }`}
      >
        DE
      </button>
    </div>
  );
}
